package com.example.project.models.enums;

public enum Role {
    USER,
    ADMIN
}
